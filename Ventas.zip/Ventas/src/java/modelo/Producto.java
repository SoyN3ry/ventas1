/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Nery
 */
public class Producto {
    int idProducto;
    String nomProducto;
    double precio;
    int stock;
    
    public Producto (int idProducto, String nomProducto, double precio, int stock){
    this.idProducto = idProducto;
    this.nomProducto = nomProducto;
    this.precio = precio;
    this.stock = stock;
    }
    
}
