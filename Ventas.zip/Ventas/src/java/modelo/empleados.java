/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Nery
 */
    public class empleados{
        int idEmpleado;
        String nombreEmpleado;
        String apellidoEmpleado;
        String user;
        String pass;
        

        public empleados () {}
public  empleados (int idEmpleado, String nombreEmpleado, String apellidoEmpleado, String user, String pass) 
{
        this.idEmpleado = idEmpleado;
        this.nombreEmpleado = nombreEmpleado;
        this.apellidoEmpleado = apellidoEmpleado;
        this.user = user;
        this.pass = pass;
}
public int getIdEmpleado() {
    return idEmpleado;
}
public void setIdEmpleado (int idEmpleado) {
    this.idEmpleado = idEmpleado;
}
public String getNombreEmpleado() {
    return nombreEmpleado;
}
public void setNombreEmpleado (String nombreEmpleado) {
    this.nombreEmpleado = nombreEmpleado;
}
public String getApellidoEmpleado() {
    return apellidoEmpleado;
}
public void setApellidoEmpleado (String apellidoEmpleado) {
    this.apellidoEmpleado = apellidoEmpleado;
}
public String getUser () {
    return user;
}
public void setUser (String user){
        this.user = user;
}
public String getPass() {
    return pass;
}
public void setPass (String pass){
    this.pass = pass;
}
    }
